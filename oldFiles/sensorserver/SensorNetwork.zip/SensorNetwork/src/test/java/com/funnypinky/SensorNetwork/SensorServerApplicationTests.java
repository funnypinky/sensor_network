package com.funnypinky.SensorNetwork;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SensorServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
